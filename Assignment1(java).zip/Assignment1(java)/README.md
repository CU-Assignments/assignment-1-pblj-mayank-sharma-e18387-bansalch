
#  Java Programming Assignment - 1

This project contains three Java programs that demonstrate basic to intermediate concepts in Java programming. All source files are located in the `src/` directory.

---

##  Contents

1. [String Analysis (Easy)](#1-string-analysis-easy)
2. [Matrix Operations (Medium)](#2-matrix-operations-medium)
3. [Basic Banking System (Hard)](#3-basic-banking-system-hard)
4. [Input/Output Examples](#4-inputoutput-examples)

---

## 1.  String Analysis (Easy)

**Description:**  
Analyzes a user-input string and counts:
- Vowels
- Consonants
- Digits
- Special Characters

 File: `src/StringAnalysis.java`

### 🔹 Sample Output
```
Enter a string: Hello World 2024!
Vowels: 3
Consonants: 7
Digits: 4
Special Characters: 3
```

---

## 2.  Matrix Operations (Medium)

**Description:**  
Performs the following operations on two 2x2 matrices:
- Addition
- Subtraction
- Multiplication

 File: `src/MatrixOperations.java`

### 🔹 Sample Output
```
Addition:
6 8
10 12

Subtraction:
-4 -4
-4 -4

Multiplication:
19 22
43 50
```

---

## 3.  Basic Banking System (Hard)

**Description:**  
Implements a basic banking system using object-oriented principles like encapsulation. Features:
- Account creation (Name, Account Number, Initial Balance)
- Deposit
- Withdrawal with overdraft protection

 File: `src/BankingSystem.java`

### 🔹 Sample Output
```
Create Account:
Name: John Doe
Account Number: 12345
Initial Balance: 1000
Deposit: 500
Withdraw: 2000

Deposit successful! Current Balance: 1500.0
Error: Insufficient funds. Current Balance: 1500.0
```

---

## 4.  Input/Output Examples

Check the `input_output_examples.txt` file in the root directory for example runs of each program.

---

Submitted by - Charu(22BCS15714)  
Assignment for Java Programming - [Submitted to Er.Mayank Sharma]

---
